<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
  <?php if(session('user')): ?>
  <div class="container mt-5">
    <!-- Cinematic background using Bootstrap classes -->
    <div class="bg-dark text-white p-5 mb-4 rounded-3" style="background-image: url('https://your-image-or-video-url.jpg'); background-size: cover; background-position: center; height: 250px;">
        <div class="container d-flex justify-content-center align-items-center" style="height: 100%;">
            <div class="text-center">
                <h3 class="fs-4">Hello, <?php echo e(session('user')->name); ?>!</h3>
                <form action="<?php echo e(route('logout')); ?>" method="GET">
                    <!-- Center the logout button -->
                    <button type="submit" class="btn btn-danger mt-3">Logout</button>
                </form>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <!-- Search Form -->
                <div class="flex-grow-1 me-3"> <!-- Added margin-end (me-3) to give space between search bar and button -->
                    <form method="GET" action="<?php echo e(route('search.users')); ?>">
                        <div class="input-group mb-3">
                            <input type="text" name="query" class="form-control" placeholder="Search the records" value="<?php echo e(request()->query('query')); ?>">
                            <button class="btn btn-outline-secondary" type="submit">Search</button>
                        </div>
                    </form>
                </div>

                <!-- Add Data Button -->
                <div>
                    <a href="/newuser" class="btn btn-primary">Add Data</a>
                </div>
            </div>

            <h1 class="text-center mt-4">All Users Data</h1>

            <!-- Alert message if no results found -->
            <?php if(isset($noResults) && $noResults): ?>
                <div class="alert alert-warning" role="alert">
                    No records found
                </div>
            <?php else: ?>
                <!-- Table with user data -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>id</th>
                                <th>name</th>
                                <th>email</th>
                                <th>phone</th>
                                <th>subject</th>
                                <th>address</th>
                                <th>country</th>
                                <th>state</th>
                                <th>city</th>
                                <th>update</th>
                                <th>delete</th>
                                <th>view</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->subject); ?></td>
                                <td><?php echo e($user->address); ?></td>
                                <td><?php echo e($user->country); ?></td>
                                <td><?php echo e($user->state); ?></td>
                                <td><?php echo e($user->city); ?></td>
                                <td><a href="<?php echo e(route('update.page', $user->id)); ?>" class="btn btn-success btn-sm">Update</a></td>
                                <td><a href="<?php echo e(route('delete.user', $user->id)); ?>" class="btn btn-danger btn-sm">Delete</a></td>
                                <td><a href="<?php echo e(route('view.user', $user->id)); ?>" class="btn btn-primary btn-sm">View</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center">
                    <?php echo e($data->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
  </div>
  <?php else: ?>
      <script>window.location.href = '<?php echo e(route('login.form')); ?>';</script>
  <?php endif; ?>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gybBfD1STBuB9z5oK0zFfRZO9kc1hG0Xj6JWiM5Xl9T/OQxT8N" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0apzFe6zRVpbzF+2p8jI/2/pyz6g5/3rbfZ6V6C8P2z9h26D" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\xampp\crud-op\resources\views/show.blade.php ENDPATH**/ ?>