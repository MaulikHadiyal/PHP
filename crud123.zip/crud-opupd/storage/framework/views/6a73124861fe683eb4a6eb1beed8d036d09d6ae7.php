<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        /* Set a full height for the body */
        html, body {
            height: 100%;
            margin: 0;
            background: url('https://st.depositphotos.com/2001755/3622/i/450/depositphotos_36220949-stock-photo-beautiful-landscape.jpg/1920x1080'); /* Background image */
            background-size: cover;
            background-position: center;
            color: #333; /* Set text color for better readability */
        }

        /* Content container with white background */
        .container {
            background-color: white; /* White background */
            padding: 30px 20px;
            border-radius: 10px;
            position: relative;
            z-index: 1;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); /* Slight shadow for elevation */
        }

        /* Centering and styling for the bg-dark section */
        .bg-dark {
            background-color: #fff;
            color: #333;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .bg-dark h3 {
            font-size: 1.5rem;
            font-weight: 700;
        }

        /* Card-style content blocks */
        .card {
            border: none;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .table {
            margin-top: 30px;
            border-radius: 8px;
            overflow: hidden;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        /* Centering <th> text */
        .table th {
            text-align: center; /* Center the text in header cells */
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Centering and spacing buttons */
        .btn {
            font-weight: 600;
            padding: 8px 16px; /* Smaller padding */
            font-size: 0.875rem; /* Smaller font size */
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }

        /* Pagination buttons */
        .pagination li {
            margin: 0 5px;
        }

        /* Additional tweaks for mobile devices */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }

            .btn {
                width: 100%;
                margin-bottom: 10px;
            }
        }

        /* Styling for the button group */
        .btn-group {
            display: flex;
            gap: 10px;  /* Space between buttons */
            justify-content: center;  /* Center the buttons */
        }
    </style>
</head>
<body>

<?php if(session('user')): ?>
<div class="container mt-5">
    <!-- User greeting section -->
    <div class="bg-warning text-center p-5 rounded-3">
        <h3 class="text-danger">Hello, <?php echo e(session('user')->name); ?>!</h3>
        <form action="<?php echo e(route('logout')); ?>" method="GET">
            <button type="submit" class="btn btn-primary mt-3">Log Out</button>
        </form>
    </div>

    <div class="row mt-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <!-- Search Form -->
                <div class="flex-grow-1 me-3">
                    <form method="GET" action="<?php echo e(route('search.users')); ?>">
                        <div class="input-group mb-3">
                            <input type="text" id="search" name="query" class="form-control" placeholder="Search the records" value="<?php echo e(request()->query('query')); ?>">
                            <button class="btn btn-outline-secondary" type="submit">Search</button>
                        </div>
                    </form>
                </div>

                <!-- Add Data Button -->
                <div>
                    <a href="/newuser" class="btn btn-primary">Add Data</a>
                </div>
            </div>

            <h1 class="text-center mb-4">All Users Data</h1>

            <!-- Alert message if no results found -->
            <?php if(isset($noResults) && $noResults): ?>
                <div class="alert alert-warning" role="alert">
                    No records found
                </div>
            <?php else: ?>
                <!-- Table with user data -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            
                                <tr>
                                    <th>id</th>
                                    <th><a href="<?php echo e(route('users.sorted', ['column' => 'name', 'direction' => (request()->get('direction') === 'asc' ? 'desc' : 'asc')])); ?>" class="text-dark" style="text-decoration: none ">name</a></th>
                                    <th><a href="<?php echo e(route('users.sorted', ['column' => 'email', 'direction' => (request()->get('direction') === 'asc' ? 'desc' : 'asc')])); ?>" class="text-dark" style="text-decoration: none ">email</a></th>
                                    <th><a href="<?php echo e(route('users.sorted', ['column' => 'phone', 'direction' => (request()->get('direction') === 'asc' ? 'desc' : 'asc')])); ?>" class="text-dark" style="text-decoration: none ">phone</a></th>
                                    <th><a href="<?php echo e(route('users.sorted', ['column' => 'subject', 'direction' => (request()->get('direction') === 'asc' ? 'desc' : 'asc')])); ?>" class="text-dark" style="text-decoration: none ">subject</a></th>
                                    <th><a href="<?php echo e(route('users.sorted', ['column' => 'address', 'direction' => (request()->get('direction') === 'asc' ? 'desc' : 'asc')])); ?>" class="text-dark" style="text-decoration: none ">address</a></th>
                                    <th><a href="<?php echo e(route('users.sorted', ['column' => 'country', 'direction' => (request()->get('direction') === 'asc' ? 'desc' : 'asc')])); ?>" class="text-dark" style="text-decoration: none ">country</a></th>
                                    <th><a href="<?php echo e(route('users.sorted', ['column' => 'state', 'direction' => (request()->get('direction') === 'asc' ? 'desc' : 'asc')])); ?>" class="text-dark" style="text-decoration: none ">state</a></th>
                                    <th><a href="<?php echo e(route('users.sorted', ['column' => 'city', 'direction' => (request()->get('direction') === 'asc' ? 'desc' : 'asc')])); ?>" class="text-dark" style="text-decoration: none ">city</a></th>
                                    <th>Operation</th>
                                </tr>
                            </tr>
                        </thead>
                        <tbody id="userTableBody">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->subject); ?></td>
                                <td><?php echo e($user->address); ?></td>
                                <td><?php echo e($user->country); ?></td>
<td><?php echo e($user->state); ?></td>
<td><?php echo e($user->city); ?></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="User Actions">
                                        <a href="<?php echo e(route('view.user', $user->id)); ?>" class="btn btn-primary btn-sm bi bi-eye"> </a>
                                        <a href="<?php echo e(route('update.page', $user->id)); ?>" class="btn btn-success btn-sm bi bi-pencil"> </a>
                                        <a href="<?php echo e(route('delete.user', $user->id)); ?>" class="btn btn-danger btn-sm bi bi-trash"></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center">
                    <?php echo e($data->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php else: ?>
    <script>window.location.href = '<?php echo e(route('login.form')); ?>';</script>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gybBfD1STBuB9z5oK0zFfRZO9kc1hG0Xj6JWiM5Xl9T/OQxT8N" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0apzFe6zRVpbzF+2p8jI/2/pyz6g5/3rbfZ6V6C8P2z9h26D" crossorigin="anonymous"></script>
<script>
document.getElementById('search').addEventListener('keyup', function() {
    let query = this.value;

    // Make an AJAX request
    fetch('/users/search?query=' + query)
        .then(response => response.json())
        .then(data => {
            let tableBody = document.getElementById('userTableBody');
            let paginationContainer = document.getElementById('pagination');
            
            // Clear the table content
            tableBody.innerHTML = ''; 

            // If no data is found
            if (data.message && data.message === 'No data found') {
                // Add a row indicating no records found
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="10" class="text-center">No records found</td>
                    </tr>
                `;
                // Hide pagination when no records are found
                paginationContainer.style.display = 'none';
            } else {
                // Insert new rows with user data
                data.users.forEach(user => {
                    let row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${user.id}</td>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>${user.phone}</td>
                        <td>${user.subject}</td>
                        <td>${user.address}</td>
                        <td>${user.country}</td>
                        <td>${user.state}</td>
                        <td>${user.city}</td>
                        <td>
                            <div class="btn-group" role="group" aria-label="User Actions">
                                <a href="/viewuser/${user.id}" class="btn btn-primary btn-sm bi bi-eye"> </a>
                                <a href="/updateuser/${user.id}" class="btn btn-success btn-sm bi bi-pencil"> </a>
                                <a href="/deleteuser/${user.id}" class="btn btn-danger btn-sm bi bi-trash"></a>
                            </div>
                        
                    `;
                    tableBody.appendChild(row);
                });

                // Update pagination if available and show pagination
                paginationContainer.innerHTML = data.pagination;
                paginationContainer.style.display = 'block'; // Show pagination when records exist
            }
        })
        .catch(error => console.error('Error fetching data:', error));
});


</script>

</body>
</html>
<?php /**PATH D:\xampp\crud-opupd\resources\views/show.blade.php ENDPATH**/ ?>