<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>show</title>
</head>
<body>
<div class="container mt-5  ">
      <div class="row d-flex justify-content-center ">
        <h1 class="row d-flex justify-content-center " > all users data</h1>
        <div class="col-6"> 

          <table class="table table-bordered table-striped">
            <th>id</th>
            <th>name</th>
           <th>email</th>
           <th>phone</th>
           <th>subject</th>
           <th>address</th>
           <th>contry</th>
           <th>state</th>
           <th>city</th>
           <th>update</th>
           <th>delete</th>
           <th>View </th>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>  <?php echo e($user->id); ?> </td>
              <td>  <?php echo e($user->name); ?> </td>
              <td><?php echo e($user->email); ?></td>
              <td> <?php echo e($user->phone); ?></td>
              <td><?php echo e($user->subject); ?></td>
              <td><?php echo e($user->address); ?></td>
              <td><?php echo e($user->country); ?></td>
              <td><?php echo e($user->state); ?></td>
              <td><?php echo e($user->city); ?></td>

              <td> <a href=" <?php echo e(route('update.page', $user->id )); ?>"><button type="submit"  class="btn btn-success btn-md rounded-0  ">update</button></a></td>
              <td> <a href="<?php echo e(route('delete.user', $user->id )); ?> "><button type="submit"  class="btn btn-danger btn-md rounded-0  ">delete</button></a></td>
              <td> <a href="<?php echo e(route('view.user', $user->id )); ?> "><button type="submit"  class="btn btn-primary btn-md rounded-0  ">view</button></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          <div>
            <?php echo e($data->links()); ?>

          </div>
          <a href="/newuser" ><button type="submit"  class="btn btn-primary btn-md rounded-0 mt-3  ">AddData</button></a>
        </div >
        <div >
       
      </div>
      </div>
      
    </div>



</body>
</html>
<?php /**PATH C:\xampp\crud-op\resources\views/show.blade.php ENDPATH**/ ?>