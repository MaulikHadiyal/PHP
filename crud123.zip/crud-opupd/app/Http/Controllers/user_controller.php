<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class user_controller extends Controller
{



    public function addUser(Request $req) {
        // Fetch the country, state, and city names from their respective tables
        $countryName = DB::table('countries')->where('id', $req->country)->value('name');
        $stateName = DB::table('states')->where('id', $req->state)->value('name');
        $cityName = DB::table('cities')->where('id', $req->city)->value('name');
    
        // Insert the user data into the database with the actual names
        $user = DB::table('user')->insert([
            'name' => $req->name,
            'email' => $req->email,
            'phone' => $req->phone,
            'subject' => $req->subject,
            'address' => $req->address,
            'country' => $countryName,  // Store the country name
            'state' => $stateName,      // Store the state name
            'city' => $cityName,        // Store the city name
        ]);
    
        if($user) {
            return redirect()->route('home');
        } else {
            return redirect()->back()->with('error', 'Not added');
        }
    }
    

    public function updateUser(Request $req, $id) {
        // Get country, state, and city names
        $countryName = DB::table('countries')->where('id', $req->country)->value('name');
        $stateName = DB::table('states')->where('id', $req->state)->value('name');
        $cityName = DB::table('cities')->where('id', $req->city)->value('name');
      
        // Update the user with their names (not IDs)
        $user = DB::table('user')->where('id', $id)->update([
            'name' => $req->name,
            'email' => $req->email,
            'phone' => $req->phone,
            'subject' => $req->subject,
            'address' => $req->address,
            'country' => $countryName,  // Country Name
            'state' => $stateName,      // State Name
            'city' => $cityName,        // City Name
        ]);
    
        if ($user) {
            return redirect()->route('home');
        } else {
            return redirect()->back()->with('error', 'Not updated');
        }
    }
    
  public function searchuser(Request $request)
  {
      // Get the search query from the request
      $query = $request->input('query');
  
      // If there's a search query, filter the data
      if ($query) {
        $user = DB::table('user')
            ->where('name', 'LIKE', "%$query%")
            ->orWhere('email', 'LIKE', "%$query%")
            ->orWhere('phone', 'LIKE', "%$query%")
            ->orWhere('subject', 'LIKE', "%$query%")
            ->orWhere('address', 'LIKE', "%$query%")
            ->orWhere('phone', 'LIKE', "%$query%")
            ->orWhere('country', 'LIKE', "%$query%")
            ->orWhere('state', 'LIKE', "%$query%")
            ->orWhere('city', 'LIKE', "%$query%")
            ->simplePaginate(4);

        // Check if no results were found
        if ($user->isEmpty()) {
            $noResults = true;
        } else {
            $noResults = false;
        }
    } else {
        // If no search query, return all users
        $user = DB::table('user')->simplePaginate(4);
        $noResults = false;
    }

    // Return the view with the data and noResults flag
    return view('show', ['data' => $user, 'noResults' => $noResults]);
}

public function showuser() {
    // Fetch users along with the names of the countries, states, and cities
    $users = DB::table('user')
        ->leftJoin('countries', 'user.country', '=', 'countries.id')  // Join countries table
        ->leftJoin('states', 'user.state', '=', 'states.id')          // Join states table
        ->leftJoin('cities', 'user.city', '=', 'cities.id')           // Join cities table
        ->select('user.*', 
                 'countries.name as country_name', 
                 'states.name as state_name', 
                 'cities.name as city_name')
        ->simplePaginate(4);

    return view('show', ['data' => $users]);
}

public function updatePage(string $id)
{
    // Get user data
    $user = DB::table('user')->find($id);

    // If user not found, handle it
    if (!$user) {
        return redirect()->back()->with('error', 'User not found');
    }

    // Get all countries
    $countries = DB::table('countries')->get();

    // Check if country_id is set, and get states if valid
    $states = $user->country ? DB::table('states')->where('country_id', $user->country)->get() : [];

    // Check if state_id is set, and get cities if valid
    $cities = $user->state ? DB::table('cities')->where('state_id', $user->state)->get() : [];

    // Return the view with data
    return view('update', [
        'data' => $user,
        'countries' => $countries,
        'states' => $states,
        'cities' => $cities
    ]);
}




public function singleUser(string $id){
  $user = DB::table('user')->where('id', $id)->get();  // Fetch the users from DB by their IDs
  return view('singleview', ['data'=>$user]);

}


public function deleteUser(string $id){
  $user = DB::table('user')->where('id',$id)->delete();

  if($user){
      return redirect('/');
  }
}


/////// add data for dropdown dynamic menu
public function showContactUsForm()
{
    $countries = DB::table('countries')->get(); 
    $states = DB::table('states')->get();
    $cities = DB::table('cities')->get();

    
    return view('contactus', compact('countries', 'states', 'cities'));
}


public function getStates($country_id)
{
    // Get the states for the selected country
    $states = DB::table('states')->where('country_id', $country_id)->get();

    return response()->json($states); // Return the states as JSON
}

public function getCities($state_id)
{
    // Get the cities for the selected state
    $cities = DB::table('cities')->where('state_id', $state_id)->get();

    return response()->json($cities); // Return the cities as JSON
}




public function showLoginForm()
{
    return view('login');
}

public function login(Request $request)
{
   
    $request->validate([
        'email_or_phone' => 'required|string',
    ]);

   
    $user = DB::table('user')
        ->where('email', $request->email_or_phone)
        ->orWhere('phone', $request->email_or_phone)
        ->first();

   
    if ($user) {
      
        session(['user' => $user]); 

        return redirect()->route('home'); 
    }

    return back()->withErrors(['email_or_phone' => 'User not found.']);
}
public function logout()
{
    session()->forget('user'); // Remove user from session
    return redirect()->route('login.form'); // Redirect back to login
}

public function authenticate(Request $request)
{
    // Get user by email or phone
    $user = DB::table('user')
        ->where('email', $request->email_or_phone)
        ->orWhere('phone', $request->email_or_phone)
        ->first();

    if ($user) {
        // Logic to log in the user (store user data in session)
        session(['user' => $user]);  // Store user data in session
        return redirect()->route('home');  // Redirect to the homepage or dashboard
    } else {
        // If user not found, flash an error message to the session
        return redirect()->back()->with('error', 'Invalid email or phone.');
    }
}
// sorting logic
public function showUsersSorted(Request $request)
{
    // Get the sort column and direction from the request, defaulting to 'name' and 'asc'
    $column = $request->input('column', 'name');
    $direction = $request->input('direction', 'asc');

    // Fetch sorted data from the 'user' table based on the column and direction
    $users = DB::table('user')
        ->leftJoin('countries', 'user.country', '=', 'countries.id') // Join countries table
        ->leftJoin('states', 'user.state', '=', 'states.id')         // Join states table
        ->leftJoin('cities', 'user.city', '=', 'cities.id')           // Join cities table
        ->select('user.*', 'countries.name as country_name', 'states.name as state_name', 'cities.name as city_name')
        ->orderBy($column, $direction)  // Sort by column and direction
        ->simplePaginate(4);

    return view('show', ['data' => $users]);
}
public function search_user(Request $request)
{
    // Get the search query
    $query = $request->input('query', '');

    // Fetch filtered data from the 'user' table based on the query
    $users = DB::table('user')
        ->leftJoin('countries', 'user.country', '=', 'countries.id') // Join countries table
        ->leftJoin('states', 'user.state', '=', 'states.id')         // Join states table
        ->leftJoin('cities', 'user.city', '=', 'cities.id')           // Join cities table
        ->select('user.*', 'countries.name as country_name', 'states.name as state_name', 'cities.name as city_name')
        ->where('user.name', 'like', "%$query%")
        ->orWhere('user.email', 'like', "%$query%")
        ->orWhere('user.phone', 'like', "%$query%")
        ->simplePaginate(4);

    // Check if no users found
    if ($users->isEmpty()) {
        return response()->json([
            'message' => 'No data found',
            'users' => [],
            'pagination' => '',
        ]);
    }

    // Return the results as JSON
    return response()->json([
        'users' => $users->items(),
        'pagination' => $users->links()->toHtml(),
    ]);
}


}
