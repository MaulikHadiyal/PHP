<?php

use App\Http\Controllers\user_controller;



use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::post('/add',[user_controller::class,'addUser'])->name('addUser');

 Route::get('/updatepage/{id}',[user_controller::class,'updatePage'])->name('update.page');

 Route::post('/update/{id}',[user_controller::class,'updateUser'])->name('update.user');

Route::get('/',[user_controller::class,'showuser'])->name('home');

Route::get('/user/{id}',[user_controller::class,'singleUser'])->name('view.user');


Route::get('/delete/{id}', [user_controller::class, 'deleteUser'])->name('delete.user');

Route::view('newuser', 'contactus'); // Display the contact us form



Route::post('/add', [user_controller::class, 'addUser'])->name('addUser');

//this is crop down menu bar routes
Route::get('/get-states/{country_id}', [user_controller::class, 'getStates']);
Route::get('/get-cities/{state_id}', [user_controller::class, 'getCities']);
Route::get('/newuser', [user_controller::class, 'showContactUsForm']);

//  // Ensure this matches the correct method

//this is drop down menu

// Route::view('view','/singleview');

Route::get('/', [user_controller::class, 'searchuser'])->name('home');
Route::get('/search', [user_controller::class, 'searchuser'])->name('search.users');  // New search route
Route::get('/users/search', [user_controller::class, 'search_user'])->name('users.search');


// Fetch states based on country_id




// login aaarea 
Route::get('/login', [User_Controller::class, 'showLoginForm'])->name('login.form');
Route::post('/login', [User_Controller::class, 'login'])->name('login');
Route::get('/logout', [User_Controller::class, 'logout'])->name('logout');

Route::post('/authenticate', [User_Controller::class, 'authenticate'])->name('login');

Route::get('/users/sorted', [user_controller::class, 'showUsersSorted'])->name('users.sorted');
