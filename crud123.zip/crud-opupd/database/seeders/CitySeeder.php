<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $filePath = database_path('data/countries_states_cities.json'); 

        if (!File::exists($filePath)) {
            dd("File not found: " . $filePath); 
        }

        $json = File::get($filePath);
        $countries = json_decode($json, true);

        if (!$countries) {
            dd("Error decoding JSON file"); 
        }

        foreach ($countries as $country) {
            foreach ($country['states'] as $state) {
                foreach ($state['cities'] as $city) {
                    City::create([
                        'cityname' => $city['name'],
                        'statename' => $state['name'],
                        'countryname' => $country['name']
                    ]);
           }
         }
       } 
    }
 }

